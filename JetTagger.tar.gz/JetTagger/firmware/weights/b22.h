//Numpy array shape [1]
//Min -0.027343750000
//Max -0.027343750000
//Number of zeros 0

#ifndef B22_H_
#define B22_H_

#ifndef __SYNTHESIS__
bias22_t b22[1];
#else
bias22_t b22[1] = {-0.027343750};
#endif

#endif
